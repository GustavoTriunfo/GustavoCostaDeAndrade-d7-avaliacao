﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SQLite;

    class ClasseDeConexao {

    private static SQLiteConnection sqliteConnection;
            public ClasseDeConexao()
            { }
            private static SQLiteConnection DbConnection()
            {
                sqliteConnection = new SQLiteConnection("Data Source=MyDatabase.sqlite;Version=3;");
                sqliteConnection.Open();
                return sqliteConnection;
            }
            public static void CriarBancoSQLite()
            {
                try
                {
                    SQLiteConnection.CreateFile(@"c:MyDatabase.sqlite;");
                }
                catch
                {
                    throw;
                }
            }
            public static void CriarTabelaSQlite()
            {
                try
                {
                    using (var cmd = DbConnection().CreateCommand())
                    {
                cmd.CommandText = "CREATE TABLE IF NOT EXISTS Clientes( Usuario Varchar(50), Senha VarChar(50))";
              
                cmd.ExecuteNonQuery();
                
            }
           
           
        }
                catch (Exception ex)
                {
                    throw ex;
                }
            }



    public static bool ValidarUsuarioConexao(string usuario, string senha)
    {
        SQLiteDataAdapter da = null;
        DataTable leituraBanco = new DataTable();
        try
        {
            string sqlText = "SELECT Usuario FROM Clientes where usuario = '" + usuario + "' and senha='" + senha + "'";
            using (var cmd = DbConnection().CreateCommand())
            {
                cmd.CommandText = sqlText;
                da = new SQLiteDataAdapter(cmd.CommandText, DbConnection());
                da.Fill(leituraBanco);
                if (leituraBanco.Rows.Count > 0)
                {
                    return true;
                }
                return false;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }


    public static void Insert()
    {
        try
        {

            using (var cmd = DbConnection().CreateCommand())
        {
                cmd.CommandText = "INSERT INTO Clientes(Usuario,Senha) SELECT'admin@email.com', 'admin123' WHERE NOT EXISTS(SELECT 1 FROM Clientes WHERE usuario = 'admin@email.com' and senha = 'admin123' );";
                cmd.ExecuteNonQuery();
            }
      
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
    }

    //public static void Add(Cliente cliente)
    //{
    //    try
    //    {
    //        using (var cmd = DbConnection().CreateCommand())
    //        {
    //            cmd.CommandText = "INSERT INTO Clientes(id, Nome, email ) values (@id, @nome, @email)";
    //            cmd.Parameters.AddWithValue("@Id", cliente.Id);
    //            cmd.Parameters.AddWithValue("@Nome", cliente.Nome);
    //            cmd.Parameters.AddWithValue("@Email", cliente.Email);
    //            cmd.ExecuteNonQuery();
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        throw ex;
    //    }
    //}
    //public static void Update(Cliente cliente)
    //{
    //    try
    //    {
    //        using (var cmd = new SQLiteCommand(DbConnection()))
    //        {
    //            if (cliente.Id != null)
    //            {
    //                cmd.CommandText = "UPDATE Clientes SET Nome=@Nome, Email=@Email WHERE Id=@Id";
    //                cmd.Parameters.AddWithValue("@Id", cliente.Id);
    //                cmd.Parameters.AddWithValue("@Nome", cliente.Nome);
    //                cmd.Parameters.AddWithValue("@Email", cliente.Email);
    //                cmd.ExecuteNonQuery();
    //            }
    //        };
    //    }
    //    catch (Exception ex)
    //    {
    //        throw ex;
    //    }
    //}
    public static void Delete()
    {
        try
        {
            using (var cmd = new SQLiteCommand(DbConnection()))
            {
                cmd.CommandText = "DROP TABLE IF EXISTS Clientes";
               
                cmd.ExecuteNonQuery();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}



