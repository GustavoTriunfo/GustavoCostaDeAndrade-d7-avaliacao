﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace D7_Avaliacao___Gustavo_Costa
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            //ClasseDeConexao.Delete();
            ClasseDeConexao.CriarBancoSQLite();
            ClasseDeConexao.CriarTabelaSQlite();
            ClasseDeConexao.Insert();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ValidarUsuario();
        }


        private void ValidarUsuario()
        {
            string usuarioDigitado = txtBoxUsuario.Text;
            string senhaDigitada = txtBoxSenha.Text;

            if (senhaDigitada.Equals(""))
            {
                MessageBox.Show("Digite a Senha!");
            }
            if (usuarioDigitado.Equals(""))
            {
                MessageBox.Show("Digite o Usuário!");
            }
            if (!usuarioDigitado.Equals("") && !senhaDigitada.Equals(""))
            {
                var retValidacao = ClasseDeConexao.ValidarUsuarioConexao(usuarioDigitado, senhaDigitada);

                if (retValidacao == true)
                {
                    WindowAutenticado popup = new();
                    popup.ShowDialog();
                }
                else
                {
                    WindowInvalido popup = new();
                    popup.ShowDialog();
                }
            }
        }

    }
}
    

